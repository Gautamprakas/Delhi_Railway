<section class="content">
            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header <?php echo BG_BLUE_GREY; ?>">
                            <h2>
                                Add Unit Of Measurment 
                            </h2>
                        </div>
                        <div class="body">
                            <div class="row clearfix">
                                <form  action="#" method="post">


                                    <div class="row clearfix">
                                        <div class='col-sm-1'></div>
                                        <div class='col-sm-6'>
                                            <div class='form-group form-float'>
                                                <div class='form-line'>
                                                    <input type='text' class='form-control' name='form_title'id="uom" required minlength='1' maxlength='500' value="" >
                                                    <label class='form-label'>UOM</label>
                                                    <div class='help-info'> </div>
                                                </div>
                                                
                                                <br>
                                                <div class=''>
                                                    <button type="submit" id="submitUom" class="btn btn-success" name="submit">
                                                     Add UOM
                                                    </button>
                                                </div>
                                            </div>
                                        </div> 
                                        <!-- <div class='col-sm-1'>
                                            <button type="submit" id="submitTrain" class="btn btn-success" name="submit">
                                                 Submit
                                            </button>
                                        </div> -->
                                        <div class="col-sm-2"></div>
                                    </div>

                                    



                                </form>
                                


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Exportable Table -->

        </div>
    </section>