<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>
                    EMPLOYEE / Employee Details
                    <small></small>
                </h2>
            </div>
            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header <?php echo BG_BLUE_GREY; ?>">
                            <h2>
                                EMPLOYEE DETAILS
                            </h2>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable" id="example">
                                    <thead class="<?php echo BG_BLUE_GREY; ?>">
                                        <tr>
                                            <th>Result</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Data Not Found</td>
                                           
                                        </tr>
                                       
                                       
                                    </tbody>
                                </table>
                           </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Exportable Table -->
        </div>
    </section>