<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-03 10:37:00 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:00 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:00 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:00 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:00 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:00 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:00 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:00 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:15 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:15 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:15 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:15 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:29 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:29 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:29 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:29 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:29 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:29 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:29 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 10:37:29 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 13:16:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:25:28 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:25:28 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:25:28 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:25:28 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:25:28 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:25:28 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:25:28 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:25:28 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:25:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:35 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:43 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:27:46 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:57 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:57 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:57 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:57 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:57 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:57 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:57 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:57 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:58 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:58 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:58 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:58 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:58 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:58 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:58 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:28:58 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:39:04 --> Query error: Unknown column 'rating' in 'field list' - Invalid query: SELECT `child_id`, `geo_loc`, `create_datetime`, `update_datetime`, `value`, `req_id`, `field_id`, `status`, `family_id`, `member_id`, `location`, `rating`
FROM `form_data_rejected`
WHERE `form_id` = '1690365766'
AND `location` like 'RAILWAY%'
ERROR - 2023-10-03 16:39:05 --> Query error: Unknown column 'rating' in 'field list' - Invalid query: SELECT `child_id`, `geo_loc`, `create_datetime`, `update_datetime`, `value`, `req_id`, `field_id`, `status`, `family_id`, `member_id`, `location`, `rating`
FROM `form_data_rejected`
WHERE `form_id` = '1690365766'
AND `location` like 'RAILWAY%'
ERROR - 2023-10-03 16:41:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:09 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:09 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:09 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:09 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:09 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:09 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:09 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:09 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:40 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:40 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:40 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:40 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:40 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:40 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:40 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:40 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:41 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:41 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:41 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:41 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:41 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:41 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:41 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:41:41 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:13 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:42:38 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:45:28 --> Query error: Unknown column 'rating' in 'field list' - Invalid query: INSERT INTO `form_data_rejected` (`approve_datetime`, `child_id`, `create_datetime`, `dept`, `family_id`, `field`, `field_id`, `field_type`, `form_for`, `form_id`, `geo_loc`, `location`, `member_id`, `rating`, `rating_datetime`, `req_id`, `status`, `title`, `update_datetime`, `value`, `work_done_datetime`) VALUES ('2023-10-03 16:45:28','V1002','2023-10-03 16:45:15','RAILWAY','fam-0e679ef9-02b5-4839-b348-4e9ba6afb400','Train Number*','1690365766_1','spinner','FAMILY','1690365766','2023-10-03 16:45:15','RAILWAY|RAILWAY|RAILWAY|RAILWAY','head-9ef05812-b11c-4507-9121-c2b96ae241c8',NULL,NULL,'51818651bf7c4e57f96.65805928','Rejected','Train Coach Details & Request To Site Manager','2023-10-03 16:45:15','12015',NULL), ('2023-10-03 16:45:28','V1002','2023-10-03 16:45:15','RAILWAY','fam-0e679ef9-02b5-4839-b348-4e9ba6afb400','Coach Number*','1690365766_2','spinner','FAMILY','1690365766','2023-10-03 16:45:15','RAILWAY|RAILWAY|RAILWAY|RAILWAY','head-9ef05812-b11c-4507-9121-c2b96ae241c8',NULL,NULL,'51818651bf7c4e57f96.65805928','Rejected','Train Coach Details & Request To Site Manager','2023-10-03 16:45:15','111571',NULL), ('2023-10-03 16:45:28','V1002','2023-10-03 16:45:15','RAILWAY','fam-0e679ef9-02b5-4839-b348-4e9ba6afb400','Coach Location*','1690365766_3','spinner','FAMILY','1690365766','2023-10-03 16:45:15','RAILWAY|RAILWAY|RAILWAY|RAILWAY','head-9ef05812-b11c-4507-9121-c2b96ae241c8',NULL,NULL,'51818651bf7c4e57f96.65805928','Rejected','Train Coach Details & Request To Site Manager','2023-10-03 16:45:15','Yard',NULL), ('2023-10-03 16:45:28','V1002','2023-10-03 16:45:15','RAILWAY','fam-0e679ef9-02b5-4839-b348-4e9ba6afb400','Toilet/ Berth No.*','1690365766_4','spinner','FAMILY','1690365766','2023-10-03 16:45:15','RAILWAY|RAILWAY|RAILWAY|RAILWAY','head-9ef05812-b11c-4507-9121-c2b96ae241c8',NULL,NULL,'51818651bf7c4e57f96.65805928','Rejected','Train Coach Details & Request To Site Manager','2023-10-03 16:45:15','Toilet-1',NULL), ('2023-10-03 16:45:28','V1002','2023-10-03 16:45:15','RAILWAY','fam-0e679ef9-02b5-4839-b348-4e9ba6afb400','Work List*','1690365766_5','spinner','FAMILY','1690365766','2023-10-03 16:45:15','RAILWAY|RAILWAY|RAILWAY|RAILWAY','head-9ef05812-b11c-4507-9121-c2b96ae241c8',NULL,NULL,'51818651bf7c4e57f96.65805928','Rejected','Train Coach Details & Request To Site Manager','2023-10-03 16:45:15','Plumbing|Wash Basin Grid and waste pipe set',NULL), ('2023-10-03 16:45:28','V1002','2023-10-03 16:45:15','RAILWAY','fam-0e679ef9-02b5-4839-b348-4e9ba6afb400','Work Status*','1690365766_6','spinner','FAMILY','1690365766','2023-10-03 16:45:15','RAILWAY|RAILWAY|RAILWAY|RAILWAY','head-9ef05812-b11c-4507-9121-c2b96ae241c8',NULL,NULL,'51818651bf7c4e57f96.65805928','Rejected','Train Coach Details & Request To Site Manager','2023-10-03 16:45:15','Replace',NULL)
ERROR - 2023-10-03 16:45:50 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:45:50 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:46:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:04 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:46:04 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:46:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:05 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:30 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:30 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:30 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:30 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:30 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:30 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:30 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:30 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:30 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:30 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:46:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:46:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:46:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:19 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:20 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:50:20 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:50:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:24 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:24 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:24 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:24 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:24 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:24 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:24 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:24 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:50:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:50:25 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:25 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:25 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:25 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:25 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:25 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:25 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:25 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 16:50:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:50:32 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:50:33 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:50:33 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 16:50:33 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 16:50:33 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:04:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:04:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:04:10 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:04:10 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:04:11 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:04:11 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:05:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:05:08 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:05:09 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:05:10 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:05:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:05:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:05:22 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:05:22 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:05:23 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:05:23 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:05:24 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:05:24 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_rejected_form_data/view_rejected_form_data.php 120
ERROR - 2023-10-03 17:06:54 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:06:54 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:07:00 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:07:00 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:07:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:03 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:04 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:07:04 --> 404 Page Not Found: Assets/layout
ERROR - 2023-10-03 17:07:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-10-03 17:07:04 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
