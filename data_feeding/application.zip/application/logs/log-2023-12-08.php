<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-08 10:50:21 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 10:50:21 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 10:50:21 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 10:50:21 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 11:07:00 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 11:07:00 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 11:07:00 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 11:07:00 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 11:09:34 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 11:09:34 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 11:09:34 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 11:09:34 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 11:09:34 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:09:34 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:09:41 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:09:41 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:09:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:09:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:10:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:10:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:10:54 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:10:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:11:04 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:11:04 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:11:16 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:11:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:13:46 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:13:46 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:13:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:13:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:13:49 --> Severity: Warning --> Undefined array key "berth" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 36
ERROR - 2023-12-08 11:13:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:13:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:13:49 --> Severity: Warning --> Undefined array key "berth" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 36
ERROR - 2023-12-08 11:13:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:13:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:13:49 --> Severity: Warning --> Undefined array key "berth" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 36
ERROR - 2023-12-08 11:13:50 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:15:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:15:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:15:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:15:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:15:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:15:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2023-12-08 11:15:41 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 11:15:41 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:12:13 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:12:14 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:14:42 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:14:42 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:17:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:39 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:39 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:39 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:39 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:39 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:39 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:46 --> 404 Page Not Found: view/CreateForm/addItem
ERROR - 2023-12-08 12:17:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:17:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:24:56 --> Severity: error --> Exception: syntax error, unexpected variable "$intent" C:\wamp64\www\railway\data_feeding\application\controllers\view\CreateForm.php 238
ERROR - 2023-12-08 12:25:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:25:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:25:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:25:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:25:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:25:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-08 12:25:34 --> Severity: Warning --> Undefined variable $i C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 27
ERROR - 2023-12-08 12:25:34 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 27
ERROR - 2023-12-08 12:25:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 27
ERROR - 2023-12-08 12:26:26 --> Severity: Warning --> Undefined variable $i C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 27
ERROR - 2023-12-08 12:27:22 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:27:23 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:27:30 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:27:49 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:27:49 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:29:07 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:29:08 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:31:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:31:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:34:43 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:34:43 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:38:53 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:38:53 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:39:12 --> Query error: Column 'item_name' cannot be null - Invalid query: INSERT INTO `railway_item` (`item_name`, `uom_value`) VALUES (NULL, 'Per Coach')
ERROR - 2023-12-08 12:40:19 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:40:20 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:40:33 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:40:33 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:41:08 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:41:08 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:44:40 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:44:41 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:44:44 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-08 12:44:44 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-08 12:44:44 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-08 12:44:44 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-08 12:44:44 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:44:45 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 12:45:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-08 12:45:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-08 12:45:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-08 12:45:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-08 16:01:13 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:01:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:01:13 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:01:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:03:27 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:03:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:03:27 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:03:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:04:23 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:04:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:04:23 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:04:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 29
ERROR - 2023-12-08 16:05:15 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:05:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:05:15 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:05:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:05:46 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:05:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:05:46 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:05:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:06:39 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:06:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:06:39 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:06:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:08:41 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:08:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:08:41 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:08:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:08:56 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:08:56 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:18:40 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:18:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:18:40 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:18:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:18:44 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:18:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:18:44 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:18:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:19:09 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:19:09 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:19:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:19:48 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:19:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:19:48 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:19:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:20:00 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:20:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:20:00 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:20:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:21:26 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:21:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:21:26 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:21:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:21:35 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:21:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:21:35 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:21:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:22:56 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:22:56 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:23:00 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:23:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:23:00 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:23:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:24:18 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:24:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:24:18 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:24:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:24:24 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:24:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:24:24 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:24:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:24:45 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:24:45 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:26:47 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:26:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:26:47 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:26:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:26:48 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:26:48 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:27:21 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:27:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:27:21 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:27:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:27:21 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:27:21 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:27:31 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:27:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:27:31 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:27:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:27:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:27:32 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:28:05 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:28:05 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:30:03 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:30:03 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:30:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:30:03 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:30:03 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:30:24 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:30:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:30:24 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:30:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:30:24 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:30:24 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:30:27 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-08 16:30:27 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-08 16:30:27 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-08 16:30:27 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-08 16:30:27 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:30:28 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:30:56 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:30:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:30:56 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:30:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 16:30:56 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:30:56 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 16:31:14 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:31:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:31:14 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:31:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-08 16:31:19 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:31:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:31:19 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:31:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-08 16:31:24 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:24 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:32 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:32 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:42 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:42 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 16:31:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-08 19:18:25 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 33
ERROR - 2023-12-08 19:18:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 33
ERROR - 2023-12-08 19:18:25 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 33
ERROR - 2023-12-08 19:18:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 33
ERROR - 2023-12-08 19:18:25 --> Severity: Warning --> Undefined array key "uom" C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 43
ERROR - 2023-12-08 19:18:25 --> Severity: Warning --> Undefined array key "uom" C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 43
ERROR - 2023-12-08 19:18:25 --> Severity: Warning --> Undefined array key "uom" C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 43
ERROR - 2023-12-08 19:19:21 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:19:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:19:21 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:19:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:19:21 --> Severity: Warning --> Undefined array key "uom" C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 41
ERROR - 2023-12-08 19:19:21 --> Severity: Warning --> Undefined array key "uom" C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 41
ERROR - 2023-12-08 19:19:21 --> Severity: Warning --> Undefined array key "uom" C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 41
ERROR - 2023-12-08 19:22:01 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:22:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:22:01 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:22:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:22:45 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:22:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:22:45 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:22:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:23:11 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 19:23:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 19:23:11 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 19:23:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-08 19:23:11 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 19:23:11 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 19:23:19 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:23:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:23:19 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:23:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:23:19 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 19:23:20 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 19:24:54 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:24:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:24:54 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:24:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 19:57:43 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 19:57:44 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 21:52:49 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:52:49 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:53:20 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:53:20 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:53:32 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:53:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:53:32 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 21:53:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:01:25 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:01:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:01:25 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:01:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:02:02 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:02:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:02:02 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:02:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:02:29 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:02:29 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:02:39 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:02:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:02:39 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:02:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:02:39 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:02:39 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:04:25 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:04:25 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:04:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:04:26 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:05:19 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:05:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:05:19 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:05:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:05:19 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:05:20 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:05:59 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:05:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:05:59 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:05:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:05:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:05:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:15:17 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:15:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:15:17 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:15:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:15:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:15:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:18:22 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:18:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:18:22 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:18:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:18:22 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:18:22 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:18:35 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:18:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:18:35 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:18:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-08 22:18:35 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-08 22:18:36 --> 404 Page Not Found: Assets/layout
