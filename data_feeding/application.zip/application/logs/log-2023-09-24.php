<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-24 08:31:49 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 821
ERROR - 2023-09-24 12:30:47 --> Severity: Warning --> file_get_contents(./application/questions/form/1690365766B .json): failed to open stream: No such file or directory /var/www/html/railway/data_feeding/application/controllers/Api.php 271
ERROR - 2023-09-24 12:44:37 --> 404 Page Not Found: Api/getFormSchema
ERROR - 2023-09-24 12:44:45 --> 404 Page Not Found: Api/FormSchema
ERROR - 2023-09-24 12:45:02 --> 404 Page Not Found: Api/formschema
ERROR - 2023-09-24 12:45:07 --> 404 Page Not Found: Api/getformschema
ERROR - 2023-09-24 12:45:25 --> 404 Page Not Found: Api/formSchema
ERROR - 2023-09-24 12:45:32 --> Severity: Warning --> file_get_contents(./application/questions/form/.json): failed to open stream: No such file or directory /var/www/html/railway/data_feeding/application/controllers/Api.php 271
ERROR - 2023-09-24 12:45:33 --> 404 Page Not Found: Api/getformSchema
ERROR - 2023-09-24 12:55:13 --> 404 Page Not Found: Api/formSchema
ERROR - 2023-09-24 14:16:03 --> Severity: Notice --> Undefined property: stdClass::$value /var/www/html/railway/data_feeding/application/controllers/Api.php 353
ERROR - 2023-09-24 14:16:03 --> Severity: Notice --> Undefined property: stdClass::$value /var/www/html/railway/data_feeding/application/controllers/Api.php 353
ERROR - 2023-09-24 14:16:03 --> Severity: Notice --> Undefined property: stdClass::$value /var/www/html/railway/data_feeding/application/controllers/Api.php 353
