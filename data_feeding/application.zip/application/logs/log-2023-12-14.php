<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-14 11:55:19 --> Severity: Warning --> Undefined array key "value" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 443
ERROR - 2023-12-14 11:55:20 --> Severity: Warning --> Undefined array key "value" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 443
ERROR - 2023-12-14 11:55:20 --> Severity: Warning --> Undefined array key "value" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 443
ERROR - 2023-12-14 11:55:20 --> Severity: Warning --> Undefined array key "value" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 443
ERROR - 2023-12-14 11:55:20 --> Severity: Warning --> Undefined array key "value" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 443
ERROR - 2023-12-14 11:55:20 --> Severity: Warning --> Undefined array key "value" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 443
ERROR - 2023-12-14 11:58:43 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, string given C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 431
ERROR - 2023-12-14 12:05:49 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, string given C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 431
ERROR - 2023-12-14 12:25:49 --> Severity: error --> Exception: Call to a member function num_rows() on string C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 429
ERROR - 2023-12-14 12:27:22 --> Severity: error --> Exception: syntax error, unexpected identifier "value" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 427
ERROR - 2023-12-14 12:28:14 --> Severity: error --> Exception: syntax error, unexpected identifier "value" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 427
ERROR - 2023-12-14 12:38:20 --> Severity: error --> Exception: syntax error, unexpected identifier "print_r" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 431
ERROR - 2023-12-14 13:08:42 --> Severity: error --> Exception: Undefined constant "db" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 430
ERROR - 2023-12-14 13:09:05 --> Query error: Unknown column 'train_numbers' in 'field list' - Invalid query: SELECT `train_numbers`
FROM `railway_trains`
ERROR - 2023-12-14 13:10:10 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:10 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:10 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:10 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:10 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:10 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:18 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:18 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:18 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:18 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:18 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:10:18 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 435
ERROR - 2023-12-14 13:31:14 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:31:14 --> Severity: Warning --> Undefined array key "train_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:32:55 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 447
ERROR - 2023-12-14 13:51:44 --> Severity: Warning --> Undefined array key "berth" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 459
ERROR - 2023-12-14 13:51:44 --> Severity: Warning --> Undefined array key "berth" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 459
ERROR - 2023-12-14 13:55:01 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-14 13:55:01 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-14 13:55:01 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-14 13:55:01 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-14 13:55:01 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-14 13:55:01 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-14 13:55:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-14 13:55:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-14 13:55:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-14 13:55:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-14 13:55:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-14 13:55:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-14 13:55:29 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-14 13:55:29 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-14 13:55:29 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-14 13:55:29 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-14 13:55:29 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-14 13:55:29 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
