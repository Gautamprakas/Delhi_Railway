<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-22 11:47:49 --> Severity: Warning --> Undefined variable $data C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 29
ERROR - 2024-01-22 11:47:49 --> Severity: Warning --> Undefined variable $data C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 32
ERROR - 2024-01-22 11:47:49 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 32
ERROR - 2024-01-22 12:19:52 --> Severity: error --> Exception: date() expects at least 1 argument, 0 given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 33
ERROR - 2024-01-22 12:20:18 --> Severity: error --> Exception: Object of class DateTime could not be converted to string C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 33
ERROR - 2024-01-22 12:20:37 --> Severity: Warning --> Undefined variable $currDate C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 36
ERROR - 2024-01-22 12:21:01 --> Severity: error --> Exception: Object of class DateTime could not be converted to string C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 36
ERROR - 2024-01-22 12:21:33 --> Severity: error --> Exception: Call to undefined method DateTime::date() C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 36
ERROR - 2024-01-22 12:21:50 --> Severity: Warning --> Undefined property: DateTime::$date C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 36
ERROR - 2024-01-22 12:22:18 --> Severity: error --> Exception: date(): Argument #1 ($format) must be of type string, DateTime given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 36
ERROR - 2024-01-22 12:23:14 --> Severity: Warning --> Undefined property: DateTime::$date C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 36
ERROR - 2024-01-22 12:23:34 --> Severity: error --> Exception: Cannot use object of type DateTime as array C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 36
ERROR - 2024-01-22 12:33:57 --> Severity: error --> Exception: DateTime::__construct(): Argument #1 ($datetime) must be of type string, array given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 32
ERROR - 2024-01-22 12:34:27 --> Severity: error --> Exception: DateTime::__construct(): Argument #1 ($datetime) must be of type string, array given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 32
ERROR - 2024-01-22 12:34:46 --> Severity: error --> Exception: DateTime::__construct(): Argument #1 ($datetime) must be of type string, array given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 32
ERROR - 2024-01-22 12:36:19 --> Severity: error --> Exception: DateTime::__construct(): Argument #1 ($datetime) must be of type string, array given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 32
ERROR - 2024-01-22 12:36:46 --> Severity: Warning --> Undefined array key "warranty_days" C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 32
ERROR - 2024-01-22 13:01:04 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, int given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 27
ERROR - 2024-01-22 13:02:16 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, int given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 27
ERROR - 2024-01-22 13:03:48 --> Severity: Warning --> Undefined variable $warrantyDay C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 25
ERROR - 2024-01-22 13:03:48 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 25
ERROR - 2024-01-22 13:04:36 --> Severity: Warning --> Undefined variable $warrantyDay C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 25
ERROR - 2024-01-22 13:04:36 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 25
ERROR - 2024-01-22 13:10:26 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 30
