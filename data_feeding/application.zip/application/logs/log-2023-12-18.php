<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-18 12:10:12 --> Severity: error --> Exception: syntax error, unexpected token "->" C:\wamp64\www\railway\data_feeding\application\controllers\view\CreateForm.php 382
ERROR - 2023-12-18 12:13:39 --> Severity: error --> Exception: syntax error, unexpected token "echo" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet.php 19
ERROR - 2023-12-18 16:41:23 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\wamp64\www\railway\data_feeding\application\controllers\view\CreateForm.php 394
