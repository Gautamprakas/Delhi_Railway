<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-11 11:57:41 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-11 11:57:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-11 11:57:41 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-11 11:57:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:57:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-11 11:58:00 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-11 11:58:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-11 11:58:00 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-11 11:58:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-11 11:58:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-11 11:58:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-11 11:58:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-11 11:58:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-11 11:58:09 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-11 11:58:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-11 11:58:09 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-11 11:58:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-11 11:58:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-11 11:58:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-11 11:58:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-11 11:58:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-11 11:58:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-11 11:58:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-11 11:58:16 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-11 11:58:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-11 11:58:16 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-11 11:58:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-11 11:58:20 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-11 11:58:20 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-11 11:58:20 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-11 11:58:20 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-11 11:58:20 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-11 11:58:20 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-11 11:58:20 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-11 11:58:20 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-11 11:58:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-11 11:58:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-11 11:58:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-11 11:58:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-11 11:58:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-11 11:58:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-11 11:58:40 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-11 11:58:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-11 11:58:40 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-11 11:58:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-11 11:58:44 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-11 11:58:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-11 11:58:44 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-11 11:58:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-11 11:58:46 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-11 11:58:46 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-11 11:58:46 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-11 11:58:46 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-11 11:58:46 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-11 11:58:46 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-11 11:58:50 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-11 11:58:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-11 11:58:50 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-11 11:58:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-11 11:58:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-11 11:58:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-11 11:58:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-11 11:58:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-11 11:58:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-11 11:58:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
