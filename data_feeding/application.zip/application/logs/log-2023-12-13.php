<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:28 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-13 13:05:55 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-13 13:05:55 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-13 13:05:55 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-13 13:05:55 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-13 13:06:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-13 13:06:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-13 13:06:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-13 13:06:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-13 13:06:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-13 13:06:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-13 13:06:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-13 13:06:12 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-13 13:34:28 --> 404 Page Not Found: Api2/prakash
ERROR - 2023-12-13 13:34:59 --> 404 Page Not Found: Api2/prakash
ERROR - 2023-12-13 13:49:10 --> 404 Page Not Found: Api2/updateformschem
ERROR - 2023-12-13 13:49:20 --> 404 Page Not Found: Api3/updateformschema
ERROR - 2023-12-13 13:55:15 --> Severity: Warning --> file_get_contents(./application/questions/form/.json): Failed to open stream: No such file or directory C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 419
ERROR - 2023-12-13 15:56:14 --> Severity: Warning --> file_get_contents(./application/questions/form/.json): Failed to open stream: No such file or directory C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 419
ERROR - 2023-12-13 15:56:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 421
ERROR - 2023-12-13 15:56:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 421
ERROR - 2023-12-13 15:56:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 421
ERROR - 2023-12-13 15:56:25 --> Severity: Warning --> file_get_contents(./application/questions/form/.json): Failed to open stream: No such file or directory C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 419
ERROR - 2023-12-13 15:56:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 421
ERROR - 2023-12-13 15:56:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 421
ERROR - 2023-12-13 15:56:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 421
