<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-18 20:46:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\wamp64\www\railway\data_feeding\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2024-02-18 20:46:56 --> Unable to connect to the database
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 99
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 142
ERROR - 2024-02-18 20:48:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 142
ERROR - 2024-02-18 20:49:16 --> 404 Page Not Found: Assets/layout
ERROR - 2024-02-18 20:49:16 --> 404 Page Not Found: Assets/layout
ERROR - 2024-02-18 20:51:37 --> 404 Page Not Found: Assets/layout
ERROR - 2024-02-18 20:51:38 --> 404 Page Not Found: Assets/layout
