<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-18 16:11:08 --> Severity: Warning --> fopen(./application/questions/form/1690365766.json): failed to open stream: Permission denied /var/www/html/railway/data_feeding/application/helpers/form_elements_helper.php 386
ERROR - 2023-09-18 16:11:08 --> Severity: Warning --> fwrite() expects parameter 1 to be resource, boolean given /var/www/html/railway/data_feeding/application/helpers/form_elements_helper.php 387
ERROR - 2023-09-18 16:11:08 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/railway/data_feeding/application/helpers/form_elements_helper.php 388
ERROR - 2023-09-18 16:12:07 --> Severity: Warning --> fopen(./application/questions/form/1690365766.json): failed to open stream: Permission denied /var/www/html/railway/data_feeding/application/helpers/form_elements_helper.php 386
ERROR - 2023-09-18 16:12:07 --> Severity: Warning --> fwrite() expects parameter 1 to be resource, boolean given /var/www/html/railway/data_feeding/application/helpers/form_elements_helper.php 387
ERROR - 2023-09-18 16:12:07 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/railway/data_feeding/application/helpers/form_elements_helper.php 388
ERROR - 2023-09-18 16:22:13 --> Severity: Warning --> fopen(./application/questions/form/1690365766.json): failed to open stream: Permission denied /var/www/html/railway/data_feeding/application/helpers/form_elements_helper.php 386
ERROR - 2023-09-18 16:22:13 --> Severity: Warning --> fwrite() expects parameter 1 to be resource, boolean given /var/www/html/railway/data_feeding/application/helpers/form_elements_helper.php 387
ERROR - 2023-09-18 16:22:13 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/railway/data_feeding/application/helpers/form_elements_helper.php 388
ERROR - 2023-09-18 16:25:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/railway/data_feeding/application/helpers/form_elements_helper.php 252
ERROR - 2023-09-18 16:39:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 16:39:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 16:39:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 16:39:44 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 16:41:12 --> 404 Page Not Found: Assets/layout
ERROR - 2023-09-18 16:41:13 --> 404 Page Not Found: Assets/layout
ERROR - 2023-09-18 16:41:38 --> 404 Page Not Found: Assets/layout
ERROR - 2023-09-18 16:55:24 --> 404 Page Not Found: Assets/layout
ERROR - 2023-09-18 17:11:47 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 17:56:32 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 18:03:03 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 18:05:09 --> Severity: Notice --> Trying to get property 'location' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 794
ERROR - 2023-09-18 18:05:09 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 828
ERROR - 2023-09-18 18:05:54 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 18:12:11 --> Severity: Notice --> Trying to get property 'location' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 794
ERROR - 2023-09-18 18:12:11 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 18:12:32 --> Severity: Notice --> Trying to get property 'location' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 794
ERROR - 2023-09-18 18:17:23 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 18:17:23 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 18:17:29 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 18:46:17 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 18:48:27 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 18:50:30 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 19:30:40 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:31:39 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:32:20 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 19:33:10 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:00:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 20:05:01 --> Severity: Notice --> Trying to get property 'form_title' of non-object /var/www/html/railway/data_feeding/application/controllers/Api.php 808
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
ERROR - 2023-09-18 22:52:56 --> Severity: Notice --> Undefined index: class /var/www/html/railway/data_feeding/application/views/view/view_form_data/view_form_data.php 120
