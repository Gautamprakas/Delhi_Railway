<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-16 12:16:51 --> 404 Page Not Found: Assets/layout
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-16 12:16:51 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-16 12:20:04 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-16 12:20:05 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-16 12:20:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-16 12:20:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-16 12:22:21 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-16 12:22:22 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-16 12:24:56 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-16 12:24:56 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-16 12:36:57 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-16 12:36:57 --> 404 Page Not Found: Assets/layout
