<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-03 14:37:55 --> Severity: error --> Exception: syntax error, unexpected variable "$row" C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 1064
ERROR - 2024-01-03 14:40:51 --> Severity: error --> Exception: syntax error, unexpected variable "$row" C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 1067
ERROR - 2024-01-03 14:41:21 --> Severity: error --> Exception: syntax error, unexpected variable "$row" C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 1067
ERROR - 2024-01-03 14:42:47 --> Severity: error --> Exception: syntax error, unexpected variable "$row" C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 1067
ERROR - 2024-01-03 14:43:24 --> Severity: error --> Exception: syntax error, unexpected variable "$row" C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 1067
ERROR - 2024-01-03 14:43:38 --> Severity: error --> Exception: syntax error, unexpected variable "$row" C:\wamp64\www\railway\data_feeding\application\controllers\Api2.php 1067
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:10:51 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\reports\data_sheet_billing.php 90
ERROR - 2024-01-03 22:11:08 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2024-01-03 22:11:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2024-01-03 22:11:08 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2024-01-03 22:11:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2024-01-03 22:11:20 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:11:20 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:11:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:36 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2024-01-03 22:11:41 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2024-01-03 22:11:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2024-01-03 22:11:41 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2024-01-03 22:11:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2024-01-03 22:11:54 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2024-01-03 22:11:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2024-01-03 22:11:54 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2024-01-03 22:11:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2024-01-03 22:13:22 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:13:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:13:22 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:13:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:16:18 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:16:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:16:18 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:16:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:16:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:16:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:16:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:16:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:16:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:16:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:16:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:16:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:17:36 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2024-01-03 22:17:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2024-01-03 22:17:36 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2024-01-03 22:17:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2024-01-03 22:17:45 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2024-01-03 22:17:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2024-01-03 22:17:45 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2024-01-03 22:17:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2024-01-03 22:17:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2024-01-03 22:17:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2024-01-03 22:17:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2024-01-03 22:17:56 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2024-01-03 22:18:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:18:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:18:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:18:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:18:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:18:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:18:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:18:02 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:18:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2024-01-03 22:18:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2024-01-03 22:18:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2024-01-03 22:18:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2024-01-03 22:18:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2024-01-03 22:18:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2024-01-03 22:18:41 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:18:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:18:41 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:18:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2024-01-03 22:21:21 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_uom.php 27
ERROR - 2024-01-03 22:21:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_uom.php 27
ERROR - 2024-01-03 22:21:21 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_uom.php 27
ERROR - 2024-01-03 22:21:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_uom.php 27
ERROR - 2024-01-03 22:21:36 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_uom.php 27
ERROR - 2024-01-03 22:21:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_uom.php 27
ERROR - 2024-01-03 22:21:36 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_uom.php 27
ERROR - 2024-01-03 22:21:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_uom.php 27
ERROR - 2024-01-03 22:21:38 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:21:38 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:21:38 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:21:38 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:21:38 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:21:38 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:21:38 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:21:38 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:21:38 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
ERROR - 2024-01-03 22:21:38 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_uom.php 34
