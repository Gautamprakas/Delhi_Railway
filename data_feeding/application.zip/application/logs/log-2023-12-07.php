<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:01:43 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:04:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:08:58 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:24:53 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:24:53 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:25:00 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:25:00 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:25:28 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:25:28 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:28:59 --> Severity: error --> Exception: syntax error, unexpected token "echo" C:\wamp64\www\railway\data_feeding\application\controllers\view\CreateForm.php 127
ERROR - 2023-12-07 11:29:14 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:29:14 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:29:22 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:29:22 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:29:47 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:29:47 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:29:57 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:29:57 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-07 11:42:42 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:42:42 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:45:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:45:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:53:32 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:53:32 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:53:37 --> Query error: Table 'vdsai_railway.railway_coach' doesn't exist - Invalid query: INSERT INTO `railway_coach` (`coach_number`, `coach_category`) VALUES ('12345', 'BNU')
ERROR - 2023-12-07 11:54:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:55:00 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:55:08 --> Query error: Table 'vdsai_railway.railway_coach' doesn't exist - Invalid query: INSERT INTO `railway_coach` (`coach_number`, `coach_category`) VALUES ('12345', 'BNU')
ERROR - 2023-12-07 11:58:18 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:58:18 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:58:28 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 11:58:29 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:07:00 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:07:01 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:07:07 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:07:07 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:07:08 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:07:08 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:12:25 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:12:25 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:12:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:12:26 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:14:17 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:14:17 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:14:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:14:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:14:24 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:14:24 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:14:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:14:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:14:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:14:50 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:14:51 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:14:51 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:15:03 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:15:03 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:15:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:15:26 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 12:15:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:15:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:16:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:16:06 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:19:16 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 12:19:16 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 14:07:00 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 14:07:00 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 14:13:33 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 14:13:33 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-07 14:26:57 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:26:57 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:27:07 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:27:07 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:27:20 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:27:20 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:30:21 --> Severity: Compile Error --> Cannot redeclare CreateForm::editCoach() C:\wamp64\www\railway\data_feeding\application\controllers\view\CreateForm.php 188
ERROR - 2023-12-07 14:30:49 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:30:50 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:30:54 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-07 14:30:54 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-07 14:30:54 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 37
ERROR - 2023-12-07 14:30:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:32:11 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-07 14:32:11 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-07 14:32:11 --> Severity: Warning --> Undefined array key "coach_number" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 37
ERROR - 2023-12-07 14:32:11 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:32:12 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:32:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-07 14:32:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-07 14:32:40 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:32:41 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:33:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-07 14:33:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-07 14:33:38 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 14:33:38 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 22:49:04 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-07 22:49:04 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-07 22:49:05 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-07 22:49:07 --> 404 Page Not Found: Assets/layout
