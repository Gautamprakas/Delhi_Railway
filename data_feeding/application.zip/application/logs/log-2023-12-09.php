<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-09 10:27:56 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:27:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:27:56 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:27:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:27:57 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 10:27:58 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 10:28:03 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 10:28:03 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 10:28:03 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 10:28:04 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 10:29:31 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:29:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:29:31 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:29:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:36:42 --> 404 Page Not Found: view/CreateForm/addWork
ERROR - 2023-12-09 10:37:00 --> 404 Page Not Found: view/CreateForm/addWork
ERROR - 2023-12-09 10:37:48 --> 404 Page Not Found: view/CreateForm/editWork
ERROR - 2023-12-09 10:38:11 --> 404 Page Not Found: view/CreateForm/editWork
ERROR - 2023-12-09 10:39:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 10:39:40 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 10:39:40 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 10:39:41 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 10:40:03 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:40:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:40:03 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:40:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 10:40:10 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:40:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:40:10 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:40:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:40:55 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:40:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:40:55 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:40:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:41:29 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:41:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:41:29 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:41:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:42:13 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:42:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:42:13 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:42:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 10:42:26 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 10:42:26 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 12:25:42 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:25:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:25:42 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:25:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:25:50 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:25:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:25:50 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:25:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:25:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 12:25:53 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 12:30:47 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:30:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:30:47 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:30:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:31:03 --> Query error: Table 'vdsai_railway.railway_work_category' doesn't exist - Invalid query: INSERT INTO `railway_work_category` (`category`) VALUES ('Carpentary')
ERROR - 2023-12-09 12:31:15 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:31:15 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:31:28 --> Query error: Table 'vdsai_railway.railway_work_category' doesn't exist - Invalid query: INSERT INTO `railway_work_category` (`category`) VALUES (NULL)
ERROR - 2023-12-09 12:32:38 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:32:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:32:38 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:32:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:32:38 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:32:38 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:32:57 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:32:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:32:57 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:32:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:32:57 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:32:58 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:33:10 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:33:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:33:10 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:33:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 12:33:11 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:33:11 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:36:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 12:36:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 12:36:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 12:36:42 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 12:36:43 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:36:43 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:37:14 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 12:37:14 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 12:37:14 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 12:37:14 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 12:37:14 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:37:14 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:38:03 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:38:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:38:03 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:38:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:38:03 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:38:04 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:39:07 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:39:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:39:07 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:39:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:39:07 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:39:08 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:41:49 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:41:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:41:49 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:41:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:41:49 --> Severity: Warning --> Undefined variable $result_item C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 47
ERROR - 2023-12-09 12:41:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 47
ERROR - 2023-12-09 12:41:49 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:41:49 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:48:13 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:48:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:48:13 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:48:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:48:13 --> Severity: Warning --> Undefined variable $result_item C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 47
ERROR - 2023-12-09 12:48:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 47
ERROR - 2023-12-09 12:48:13 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:48:13 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:48:55 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:48:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:48:55 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:48:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:48:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:48:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:49:32 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:49:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:49:32 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:49:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 12:49:32 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 12:49:32 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:06:21 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:06:22 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:18:13 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 13:18:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 13:18:13 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 13:18:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 13:18:13 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:18:14 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:21:18 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 13:21:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 13:21:18 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 13:21:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work.php 32
ERROR - 2023-12-09 13:21:18 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:21:19 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:21:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 13:21:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 13:21:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 13:21:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-09 13:21:32 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:21:32 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:22:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:22:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:22:43 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:22:43 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:24:56 --> Severity: Warning --> Undefined variable $data C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 33
ERROR - 2023-12-09 13:24:56 --> Severity: Warning --> Attempt to read property "step1" on null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 33
ERROR - 2023-12-09 13:24:56 --> Severity: Warning --> Attempt to read property "title" on null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 33
ERROR - 2023-12-09 13:24:56 --> Severity: Warning --> Undefined variable $data C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 47
ERROR - 2023-12-09 13:24:56 --> Severity: Warning --> Attempt to read property "step1" on null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 47
ERROR - 2023-12-09 13:24:56 --> Severity: Warning --> Attempt to read property "fields" on null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 47
ERROR - 2023-12-09 13:24:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 47
ERROR - 2023-12-09 13:24:56 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:24:57 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:26:03 --> Severity: Warning --> Undefined variable $data C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 33
ERROR - 2023-12-09 13:26:03 --> Severity: Warning --> Attempt to read property "step1" on null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 33
ERROR - 2023-12-09 13:26:03 --> Severity: Warning --> Attempt to read property "title" on null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 33
ERROR - 2023-12-09 13:26:03 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:26:03 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:26:30 --> Severity: Warning --> Undefined variable $data C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 33
ERROR - 2023-12-09 13:26:30 --> Severity: Warning --> Attempt to read property "step1" on null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 33
ERROR - 2023-12-09 13:26:30 --> Severity: Warning --> Attempt to read property "title" on null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_work2.php 33
ERROR - 2023-12-09 13:26:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:26:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:27:01 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:27:01 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:27:51 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:27:51 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:28:35 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:28:36 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:28:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:28:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:29:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:29:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:30:07 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:30:08 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:30:40 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:30:41 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:32:08 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:32:08 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:32:14 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:32:14 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:32:20 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:32:20 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:33:11 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:33:11 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:33:15 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:33:16 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:33:41 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:33:42 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:34:05 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:34:06 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:34:35 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:34:36 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:35:06 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:35:06 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:35:22 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:35:22 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:35:46 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:35:47 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:36:12 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:36:13 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:36:44 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:36:44 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:37:26 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:37:27 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:37:50 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:37:51 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:39:07 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:39:08 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:40:21 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:40:22 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:41:14 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:41:15 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:41:54 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:41:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:45:42 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:45:42 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:46:14 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:46:15 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:46:52 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:46:52 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:48:18 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:48:19 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:48:43 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:48:43 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:49:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:49:25 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:49:37 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 13:49:37 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:04:44 --> Query error: Column 'work_code' cannot be null - Invalid query: INSERT INTO `railway_work` (`item_name`, `uom`, `work_code`, `work_name`, `work_category`, `work_rate`) VALUES ('Door Handle', 'Per Coach', NULL, NULL, 'Trimming', NULL)
ERROR - 2023-12-09 14:04:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:04:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:05:06 --> Query error: Column 'item_name' cannot be null - Invalid query: INSERT INTO `railway_work` (`item_name`, `uom`, `work_code`, `work_name`, `work_category`, `work_rate`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2023-12-09 14:06:04 --> Query error: Column 'work_code' cannot be null - Invalid query: INSERT INTO `railway_work` (`item_name`, `uom`, `work_code`, `work_name`, `work_category`, `work_rate`) VALUES ('Roller Blinder', 'Per Coach', NULL, NULL, 'Trimming', NULL)
ERROR - 2023-12-09 14:11:02 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:11:03 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:11:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:11:18 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:12:58 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:12:58 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:13:16 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-09 14:13:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-09 14:13:16 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-09 14:13:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-09 14:13:16 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:13:17 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:13:42 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-09 14:13:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-09 14:13:42 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-09 14:13:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-09 14:13:42 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:13:43 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:13:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-09 14:13:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-09 14:13:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-09 14:13:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-09 14:13:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-09 14:13:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-09 14:13:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-09 14:13:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-09 14:13:46 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:13:46 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:14:31 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 14:14:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 14:14:31 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 14:14:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 14:14:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:14:31 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:14:54 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 14:14:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 14:14:54 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 14:14:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-09 14:14:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:14:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:14:59 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:14:59 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:14:59 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:14:59 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:14:59 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:14:59 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:14:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:14:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:15:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:15:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:15:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:15:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:15:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:15:37 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:15:37 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:15:38 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:25:22 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:25:22 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:25:22 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:25:22 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:25:22 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:25:22 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:25:31 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:25:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:25:31 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:25:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:25:51 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:25:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:25:51 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:25:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:26:04 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:26:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:26:04 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:26:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:26:34 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:26:34 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:26:40 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:26:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:26:40 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:26:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:26:40 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:26:40 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:27:04 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:27:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:27:04 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:27:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:27:04 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:27:05 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:27:59 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:27:59 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:27:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:27:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:27:59 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:28:10 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:10 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:11 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:28:11 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:28:28 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:28 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:34 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:34 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:37 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:37 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:45 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:45 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:54 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:54 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:28:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:31:33 --> Severity: error --> Exception: syntax error, unexpected string content "", expecting "-" or identifier or variable or number C:\wamp64\www\railway\data_feeding\application\controllers\view\CreateForm.php 372
ERROR - 2023-12-09 14:31:50 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:31:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:31:50 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:31:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 14:31:51 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:31:51 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:31:54 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:31:54 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:31:54 --> Severity: Warning --> Undefined array key "category" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 36
ERROR - 2023-12-09 14:31:54 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:31:54 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:31:54 --> Severity: Warning --> Undefined array key "category" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 36
ERROR - 2023-12-09 14:31:54 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:31:54 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:31:54 --> Severity: Warning --> Undefined array key "category" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 36
ERROR - 2023-12-09 14:31:54 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:31:55 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:32:18 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:32:18 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:32:18 --> Severity: Warning --> Undefined array key "category" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 36
ERROR - 2023-12-09 14:32:18 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:32:18 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:32:18 --> Severity: Warning --> Undefined array key "category" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 36
ERROR - 2023-12-09 14:32:18 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:32:18 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:32:18 --> Severity: Warning --> Undefined array key "category" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 36
ERROR - 2023-12-09 14:32:18 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:32:19 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:33:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:33:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:33:09 --> Severity: Warning --> Undefined array key "category" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 36
ERROR - 2023-12-09 14:33:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:33:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:33:09 --> Severity: Warning --> Undefined array key "category" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 36
ERROR - 2023-12-09 14:33:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:33:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-09 14:33:09 --> Severity: Warning --> Undefined array key "category" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 36
ERROR - 2023-12-09 14:33:09 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:33:09 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:34:33 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-09 14:34:33 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-09 14:34:33 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-09 14:34:33 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-09 14:34:33 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-09 14:34:33 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-09 14:34:33 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 14:34:33 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-09 16:33:02 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 16:33:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 16:33:02 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-09 16:33:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
