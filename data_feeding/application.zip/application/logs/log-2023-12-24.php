<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-24 15:57:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php:547) C:\wamp64\www\railway\data_feeding\system\core\Common.php 570
ERROR - 2023-12-24 15:57:27 --> Severity: Error --> Allowed memory size of 2097152000 bytes exhausted (tried to allocate 4096 bytes) C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 547
ERROR - 2023-12-24 16:03:53 --> Severity: error --> Exception: syntax error, unexpected token "}", expecting ";" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 562
ERROR - 2023-12-24 16:04:42 --> Severity: error --> Exception: syntax error, unexpected token "}", expecting ";" C:\wamp64\www\railway\data_feeding\application\helpers\form_elements_helper.php 562
