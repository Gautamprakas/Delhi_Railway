<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-12 10:39:00 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-12 10:39:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-12 10:39:00 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-12 10:39:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_train.php 27
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:32 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_train.php 36
ERROR - 2023-12-12 10:39:55 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-12 10:39:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-12 10:39:55 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-12 10:39:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_coach.php 28
ERROR - 2023-12-12 10:40:18 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-12 10:40:18 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-12 10:40:18 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-12 10:40:18 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_coach.php 37
ERROR - 2023-12-12 10:44:03 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-12 10:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-12 10:44:03 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-12 10:44:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_berth.php 27
ERROR - 2023-12-12 10:44:19 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-12 10:44:19 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-12 10:44:19 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-12 10:44:19 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-12 10:44:19 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-12 10:44:19 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_berth.php 34
ERROR - 2023-12-12 10:44:32 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-12 10:44:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-12 10:44:32 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-12 10:44:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_item.php 30
ERROR - 2023-12-12 10:44:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-12 10:44:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-12 10:44:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-12 10:44:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-12 10:44:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-12 10:44:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-12 10:44:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-12 10:44:49 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_item.php 35
ERROR - 2023-12-12 10:45:16 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-12 10:45:16 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-12 10:45:16 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-12 10:45:16 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-12 10:45:16 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-12 10:45:16 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_work.php 38
ERROR - 2023-12-12 10:45:31 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-12 10:45:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-12 10:45:31 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-12 10:45:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_category.php 27
ERROR - 2023-12-12 10:45:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-12 10:45:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-12 10:45:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-12 10:45:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-12 10:45:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-12 10:45:45 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_category.php 34
ERROR - 2023-12-12 10:45:58 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-12 10:45:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-12 10:45:58 --> Severity: Warning --> Undefined variable $row C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-12 10:45:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\views\view\master\add_status.php 27
ERROR - 2023-12-12 10:46:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 10:46:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 10:46:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 10:46:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 10:46:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 10:46:09 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:32:34 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:32:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:32:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:32:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:32:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:32:35 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:33:14 --> 404 Page Not Found: Api/auth
ERROR - 2023-12-12 15:59:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:59:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:59:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:59:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:59:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:59:41 --> Severity: Warning --> Undefined array key "class" C:\wamp64\www\railway\data_feeding\application\views\view\master\edit_status.php 32
ERROR - 2023-12-12 15:59:57 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-12 16:15:30 --> Severity: Warning --> file_get_contents(./application/questions/form/.json): Failed to open stream: No such file or directory C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 272
ERROR - 2023-12-12 16:15:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:15:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:15:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:15:48 --> Severity: Warning --> file_get_contents(./application/questions/form/162461.json): Failed to open stream: No such file or directory C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 272
ERROR - 2023-12-12 16:15:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:15:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:15:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:30:17 --> Severity: error --> Exception: syntax error, unexpected identifier "getPrakashData", expecting variable C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 297
ERROR - 2023-12-12 16:30:28 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-12 16:30:41 --> 404 Page Not Found: Assets/layout
ERROR - 2023-12-12 16:31:40 --> Severity: Warning --> file_get_contents(./application/questions/form/162461.json): Failed to open stream: No such file or directory C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 272
ERROR - 2023-12-12 16:31:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:31:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:31:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:32:23 --> Severity: Warning --> file_get_contents(./application/questions/form/1690365766_1.json): Failed to open stream: No such file or directory C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 272
ERROR - 2023-12-12 16:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
ERROR - 2023-12-12 16:32:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\wamp64\www\railway\data_feeding\application\controllers\Api.php 275
